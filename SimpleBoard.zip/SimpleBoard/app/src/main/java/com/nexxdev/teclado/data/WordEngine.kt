package com.nexxdev.teclado.data

import android.content.Context
import java.io.File
import java.text.Normalizer
import kotlin.math.abs

/**
 * Motor de predicción y autocorrección 100% local (sin red, sin servidor).
 *
 *  - assets/words_es.txt: diccionario base (por frecuencia aproximada).
 *  - files/user_words.txt: palabras que TÚ escribes (con contador).
 *  - files/user_pairs.txt: parejas "palabra -> siguiente" para predecir la próxima palabra.
 *
 * Una palabra tuya cuenta como "conocida" cuando la has escrito [TRUST] veces, o cuando
 * rechazas una corrección (borrar justo después de corregir). Así nunca "aprende" tus
 * erratas a la primera, pero sí tus nombres, jerga y palabras nuevas.
 */
class WordEngine(private val ctx: Context) {

    companion object {
        private const val TRUST = 2
        private val MARKS = Regex("\\p{Mn}+")

        fun normalize(s: String): String =
            Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(MARKS, "")
    }

    private val base = ArrayList<String>()
    private val baseRank = HashMap<String, Int>()
    private val normIndex = HashMap<String, MutableList<String>>()   // sin acentos -> palabras
    private val user = HashMap<String, Int>()
    private val pairs = HashMap<String, HashMap<String, Int>>()
    private var dirty = false

    private val wordsFile: File get() = File(ctx.filesDir, "user_words.txt")
    private val pairsFile: File get() = File(ctx.filesDir, "user_pairs.txt")

    init {
        try {
            ctx.assets.open("words_es.txt").bufferedReader().useLines { seq ->
                seq.map { it.trim().lowercase() }.filter { it.isNotEmpty() }.forEach {
                    if (!baseRank.containsKey(it)) {
                        baseRank[it] = base.size
                        base.add(it)
                    }
                }
            }
        } catch (_: Exception) {
        }
        loadUser()
        rebuildNorm()
    }

    // ------------------------------------------------------------ carga / guardado

    private fun loadUser() {
        user.clear()
        pairs.clear()
        try {
            if (wordsFile.exists()) wordsFile.forEachLine { line ->
                val p = line.split('\t')
                if (p.size == 2) user[p[0]] = p[1].toIntOrNull() ?: 1
            }
            if (pairsFile.exists()) pairsFile.forEachLine { line ->
                val p = line.split('\t')
                if (p.size == 3) pairs.getOrPut(p[0]) { HashMap() }[p[1]] = p[2].toIntOrNull() ?: 1
            }
        } catch (_: Exception) {
        }
    }

    private fun rebuildNorm() {
        normIndex.clear()
        base.forEach { indexNorm(it) }
        user.forEach { (w, n) -> if (n >= TRUST) indexNorm(w) }
    }

    private fun indexNorm(w: String) {
        val l = normIndex.getOrPut(normalize(w)) { ArrayList() }
        if (!l.contains(w)) l.add(w)
    }

    /** Si el usuario borró sus datos desde Ajustes, vacía también la memoria. */
    fun syncIfCleared() {
        if (!wordsFile.exists() && !pairsFile.exists() &&
            (user.isNotEmpty() || pairs.isNotEmpty()) && !dirty
        ) {
            user.clear()
            pairs.clear()
            rebuildNorm()
        }
    }

    fun save() {
        if (!dirty) return
        try {
            wordsFile.writeText(user.entries.joinToString("\n") { "${it.key}\t${it.value}" })
            pairsFile.writeText(
                pairs.entries.joinToString("\n") { (a, m) ->
                    m.entries.joinToString("\n") { "$a\t${it.key}\t${it.value}" }
                }
            )
            dirty = false
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------ consulta

    private fun known(w: String) = baseRank.containsKey(w) || (user[w] ?: 0) >= TRUST

    /** Menor = mejor. Las palabras del usuario (más usadas primero) ganan al diccionario base. */
    private fun rank(w: String): Int {
        val n = user[w] ?: 0
        return if (n >= TRUST) -n else (baseRank[w] ?: (Int.MAX_VALUE / 2))
    }

    fun matchCase(typed: String, word: String): String = when {
        typed.length > 1 && typed.all { it.isUpperCase() } -> word.uppercase()
        typed.isNotEmpty() && typed.first().isUpperCase() -> word.replaceFirstChar { it.uppercase() }
        else -> word
    }

    /** Completa lo que estás escribiendo. */
    fun suggest(prefix: String, max: Int = 3): List<String> {
        val p = prefix.lowercase()
        if (p.isEmpty()) return emptyList()
        val out = LinkedHashSet<String>()
        user.entries
            .filter { it.value >= TRUST && it.key.startsWith(p) && it.key != p }
            .sortedByDescending { it.value }
            .take(max)
            .forEach { out.add(it.key) }
        for (w in base) {
            if (out.size >= max) break
            if (w.startsWith(p) && w != p) out.add(w)
        }
        return out.map { matchCase(prefix, it) }
    }

    /** Predice la palabra siguiente según lo que ya has escrito antes. */
    fun nextWords(prev: String, max: Int = 3): List<String> =
        pairs[prev.lowercase()]?.entries
            ?.sortedByDescending { it.value }
            ?.take(max)
            ?.map { it.key }
            .orEmpty()

    /**
     * Devuelve la corrección de [word] o null si está bien / no hay candidato seguro.
     * level 1 = acentos y letras cambiadas de sitio; level 2 = también una letra de más/menos.
     */
    fun correct(word: String, level: Int): String? {
        if (level <= 0) return null
        val w = word.lowercase()
        if (w.length < 3 || !w.all { it.isLetter() } || known(w)) return null

        // 1) Solo faltan o sobran acentos / ñ ("tambien" -> "también")
        normIndex[normalize(w)]?.filter { it != w }?.minByOrNull { rank(it) }?.let { return it }
        if (w.length < 4) return null

        // 2) Una sola edición
        var best: String? = null
        var bestRank = Int.MAX_VALUE
        fun consider(c: String) {
            if (abs(c.length - w.length) > 1) return
            val ok = if (level >= 2) osa(w, c) == 1 else isSwap(w, c)
            if (!ok) return
            val r = rank(c)
            if (best == null || r < bestRank) {
                best = c
                bestRank = r
            }
        }
        for (c in base) consider(c)
        for ((c, n) in user) if (n >= TRUST) consider(c)
        return best
    }

    // ------------------------------------------------------------ aprendizaje

    /** Aprende una palabra terminada (y la pareja con la anterior). */
    fun learn(word: String, prev: String = "") {
        val w = word.lowercase()
        if (w.length < 2 || !w.all { it.isLetter() }) return
        val n = (user[w] ?: 0) + 1
        user[w] = n
        if (n == TRUST) indexNorm(w)
        if (prev.isNotEmpty()) {
            val m = pairs.getOrPut(prev.lowercase()) { HashMap() }
            m[w] = (m[w] ?: 0) + 1
            if (pairs.size > 5000) pairs.entries.removeAll { e -> e.value.values.sum() <= 1 }
        }
        dirty = true
    }

    /** El usuario deshizo una corrección: esa palabra es válida para él. */
    fun reject(word: String) {
        val w = word.lowercase()
        if (w.length < 2 || !w.all { it.isLetter() }) return
        user[w] = maxOf(user[w] ?: 0, TRUST) + 1
        indexNorm(w)
        dirty = true
    }

    // ------------------------------------------------------------ distancias

    private fun isSwap(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var i = 0
        while (i < a.length && a[i] == b[i]) i++
        if (i >= a.length - 1) return false
        if (a[i] != b[i + 1] || a[i + 1] != b[i]) return false
        return a.substring(i + 2) == b.substring(i + 2)
    }

    /** Distancia de edición con transposición adyacente (Damerau/OSA). */
    private fun osa(a: String, b: String): Int {
        val n = a.length
        val m = b.length
        val d = Array(n + 1) { IntArray(m + 1) }
        for (i in 0..n) d[i][0] = i
        for (j in 0..m) d[0][j] = j
        for (i in 1..n) for (j in 1..m) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            var v = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                v = minOf(v, d[i - 2][j - 2] + 1)
            }
            d[i][j] = v
        }
        return d[n][m]
    }
}
