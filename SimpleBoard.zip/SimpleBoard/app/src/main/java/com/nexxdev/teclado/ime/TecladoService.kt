package com.nexxdev.teclado.ime

import android.content.ClipboardManager
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import com.nexxdev.teclado.R
import com.nexxdev.teclado.SettingsActivity
import com.nexxdev.teclado.data.ClipStore
import com.nexxdev.teclado.data.KeyboardPrefs
import com.nexxdev.teclado.data.WordEngine
import com.nexxdev.teclado.ui.TecladoView

/**
 * Servicio del teclado (Simple Board). La UI vive en TecladoView; aquí está la lógica
 * que habla con el campo de texto: insertar, borrar, autocorregir y aprender.
 */
class TecladoService : InputMethodService(), TecladoView.Listener {

    private data class Correction(val original: String, val committed: String, val sep: String)

    private lateinit var prefs: KeyboardPrefs
    private lateinit var words: WordEngine
    private var tecladoView: TecladoView? = null
    private var clipboard: ClipboardManager? = null

    private var isPassword = false
    private var suggestionsAllowed = true
    private var autoCapAllowed = true
    private var lastSpaceTime = 0L
    private var lastCorrection: Correction? = null

    private val sentenceEnd = Regex("[.!?¿¡]\\s*$")
    private val noSeparator = setOf("'", "’", "-", "_", "@", "#", "/")
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    override fun onCreate() {
        super.onCreate()
        prefs = KeyboardPrefs(this)
        words = WordEngine(this)
        clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        clipboard?.removePrimaryClipChangedListener(clipListener)
        words.save()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val v = layoutInflater.inflate(R.layout.keyboard_view, null) as TecladoView
        v.listener = this
        tecladoView = v
        return v
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION

        val textPass = cls == InputType.TYPE_CLASS_TEXT && (
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
        val numPass = cls == InputType.TYPE_CLASS_NUMBER &&
            variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
        isPassword = textPass || numPass

        val noSuggest = cls != InputType.TYPE_CLASS_TEXT ||
            (info.inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0 ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI
        suggestionsAllowed = !isPassword && !noSuggest
        autoCapAllowed = cls == InputType.TYPE_CLASS_TEXT && !isPassword
        lastCorrection = null

        words.syncIfCleared()

        val symbols = cls == InputType.TYPE_CLASS_NUMBER ||
            cls == InputType.TYPE_CLASS_PHONE ||
            cls == InputType.TYPE_CLASS_DATETIME
        tecladoView?.onStartInput(symbols)
        tecladoView?.setEnterLabel(enterLabel(info))
        refreshState()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        words.save()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(
            oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd
        )
        refreshState()
    }

    // ------------------------------------------------ estado: mayúscula + sugerencias

    private fun refreshState() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        if (prefs.autoCap && autoCapAllowed && ei != null && ei.inputType != 0) {
            tecladoView?.setShiftAuto(ic.getCursorCapsMode(ei.inputType) != 0)
        }
        updateSuggestions()
    }

    private fun currentWord(before: CharSequence?): String =
        before?.toString().orEmpty().takeLastWhile { it.isLetter() }

    /** Palabra anterior a la actual (solo si hay un espacio entre ambas y sin puntuación). */
    private fun previousWord(prefix: String): String {
        val t = prefix.trimEnd()
        if (t.length == prefix.length) return ""
        return t.takeLastWhile { it.isLetter() }
    }

    private fun level(): Int = when (prefs.autocorrect) {
        "normal" -> 2
        "soft" -> 1
        else -> 0
    }

    /** No corrige nombres propios a mitad de frase, SIGLAS, ni cosas pegadas a @ / # / números. */
    private fun allowCorrection(word: String, prefix: String): Boolean {
        if (word.length < 3) return false
        if (word.drop(1).any { it.isUpperCase() }) return false
        val last = prefix.lastOrNull()
        if (last != null && (last.isDigit() || last in "@#/._-")) return false
        if (word[0].isUpperCase()) {
            val sentenceStart = prefix.isBlank() || sentenceEnd.containsMatchIn(prefix) || prefix.endsWith("\n")
            if (!sentenceStart) return false
        }
        return true
    }

    private fun slots(left: String?, center: String?, right: String?) = listOf(
        TecladoView.Sug(left.orEmpty()),
        TecladoView.Sug(center.orEmpty(), primary = true),
        TecladoView.Sug(right.orEmpty())
    )

    private fun updateSuggestions() {
        val v = tecladoView ?: return
        if (!prefs.suggestions || !suggestionsAllowed) {
            v.setSuggestions(emptyList())
            return
        }
        val before = currentInputConnection?.getTextBeforeCursor(64, 0)?.toString().orEmpty()
        val word = currentWord(before)
        val prefix = before.dropLast(word.length)

        if (word.isEmpty()) {
            val prev = if (before.isNotEmpty() && before.last().isWhitespace()) previousWord(before) else ""
            val n = if (prev.isNotEmpty()) words.nextWords(prev, 3) else emptyList()
            v.setSuggestions(slots(n.getOrNull(1), n.getOrNull(0), n.getOrNull(2)))
            return
        }

        val cands = words.suggest(word, 3)
        val corr = if (level() > 0 && allowCorrection(word, prefix)) words.correct(word, level()) else null
        if (corr != null) {
            val c = words.matchCase(word, corr)
            val others = cands.filter { !it.equals(c, true) }
            v.setSuggestions(
                listOf(
                    TecladoView.Sug(word, "“$word”"),
                    TecladoView.Sug(c, c, true),
                    TecladoView.Sug(others.getOrNull(0).orEmpty())
                )
            )
        } else {
            v.setSuggestions(slots(cands.getOrNull(1), cands.getOrNull(0), cands.getOrNull(2)))
        }
    }

    /**
     * Se llama al terminar una palabra (espacio, puntuación o Enter). Aprende la palabra
     * y, si procede, la autocorrige. Devuelve true si ya insertó el separador.
     */
    private fun finishWord(ic: InputConnection, sep: String): Boolean {
        if (isPassword || !suggestionsAllowed || sep in noSeparator) return false
        val before = ic.getTextBeforeCursor(64, 0)?.toString().orEmpty()
        val word = currentWord(before)
        if (word.isEmpty()) return false
        val prefix = before.dropLast(word.length)
        val prev = previousWord(prefix)

        var finalWord = word
        if (level() > 0 && allowCorrection(word, prefix)) {
            words.correct(word, level())?.let { finalWord = words.matchCase(word, it) }
        }
        val corrected = finalWord != word
        if (prefs.learn) words.learn(finalWord, prev)
        if (!corrected) return false

        ic.beginBatchEdit()
        ic.deleteSurroundingText(word.length, 0)
        ic.commitText(finalWord + sep, 1)
        ic.endBatchEdit()
        lastCorrection = Correction(word, finalWord, sep)
        return true
    }

    private fun enterLabel(info: EditorInfo): String {
        if ((info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) return "⏎"
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "⏎"
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "Ir"
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_SEND -> "Enviar"
            EditorInfo.IME_ACTION_NEXT -> "Sig."
            EditorInfo.IME_ACTION_DONE -> "✓"
            else -> "⏎"
        }
    }

    // ------------------------------------------------ TecladoView.Listener

    override fun onText(text: String) {
        val ic = currentInputConnection ?: return
        lastCorrection = null
        if (text == " ") {
            val now = SystemClock.uptimeMillis()
            if (prefs.doubleSpace && now - lastSpaceTime < 450) {
                val before = ic.getTextBeforeCursor(2, 0)
                if (before != null && before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                    ic.deleteSurroundingText(1, 0)
                    ic.commitText(". ", 1)
                    lastSpaceTime = 0
                    return
                }
            }
            lastSpaceTime = now
        } else {
            lastSpaceTime = 0
        }
        val isSeparator = text.length == 1 && (text[0].isWhitespace() || !text[0].isLetterOrDigit())
        if (isSeparator && finishWord(ic, text)) return
        ic.commitText(text, 1)
    }

    override fun onDelete() {
        val c = lastCorrection
        if (c != null) {
            lastCorrection = null
            val ic = currentInputConnection
            if (ic != null) {
                val expected = c.committed + c.sep
                val before = ic.getTextBeforeCursor(expected.length, 0)?.toString()
                if (before == expected) {
                    // Deshacer la autocorrección y recordar que esa palabra es válida
                    ic.beginBatchEdit()
                    ic.deleteSurroundingText(expected.length, 0)
                    ic.commitText(c.original, 1)
                    ic.endBatchEdit()
                    if (prefs.learn) words.reject(c.original)
                    return
                }
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        lastCorrection = null
        finishWord(ic, "")
        lastCorrection = null
        val multi = ei != null && (ei.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        val noAction = ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        val action = if (ei != null) ei.imeOptions and EditorInfo.IME_MASK_ACTION else EditorInfo.IME_ACTION_NONE
        if (multi || noAction || action == EditorInfo.IME_ACTION_NONE ||
            action == EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            ic.performEditorAction(action)
        }
    }

    override fun onSuggestion(word: String) {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(64, 0)?.toString().orEmpty()
        val current = currentWord(before)
        val prev = previousWord(before.dropLast(current.length))
        lastCorrection = null
        ic.beginBatchEdit()
        if (current.isNotEmpty()) ic.deleteSurroundingText(current.length, 0)
        ic.commitText("$word ", 1)
        ic.endBatchEdit()
        if (prefs.learn && !isPassword) {
            // Elegir la palabra tal como la escribiste = "esta palabra es válida"
            if (word == current) words.reject(word) else words.learn(word, prev)
        }
    }

    override fun onKey(keyCode: Int, meta: Int) {
        val ic = currentInputConnection ?: return
        val t = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, keyCode, 0, meta))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, keyCode, 0, meta))
    }

    override fun onMenuAction(id: Int) {
        currentInputConnection?.performContextMenuAction(id)
    }

    override fun onCursorSteps(steps: Int) {
        val code = if (steps < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        repeat(kotlin.math.abs(steps)) { onKey(code, 0) }
    }

    override fun onOpenSettings() {
        startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onPickKeyboard() {
        getSystemService(InputMethodManager::class.java)?.showInputMethodPicker()
    }

    // ------------------------------------------------ Portapapeles

    private fun captureClip() {
        if (isPassword) return
        val clip = clipboard?.primaryClip ?: return
        if (clip.itemCount == 0) return
        val extras = clip.description.extras
        if (extras != null && extras.getBoolean("android.content.extra.IS_SENSITIVE", false)) return
        val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim()
        if (!text.isNullOrEmpty()) ClipStore.add(text)
    }
}
