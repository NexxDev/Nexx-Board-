package com.nexxdev.teclado.ui

enum class KeyType { CHAR, SPACE, SHIFT, DELETE, ENTER, SYMBOLS, LETTERS, MORE, SYMBOLS_BACK, EMOJI }

/** weight = ancho relativo dentro de la fila; alts = caracteres de pulsación larga. */
data class Key(
    val label: String,
    val type: KeyType = KeyType.CHAR,
    val weight: Float = 1f,
    val alts: List<String> = emptyList()
)

object KeyLayouts {
    private val ALTS = mapOf(
        'a' to listOf("á", "à", "ä", "â", "ã", "å"),
        'e' to listOf("é", "è", "ë", "ê"),
        'i' to listOf("í", "ì", "ï", "î"),
        'o' to listOf("ó", "ò", "ö", "ô", "õ"),
        'u' to listOf("ú", "ù", "ü", "û"),
        'n' to listOf("ń"),
        'c' to listOf("ç", "ć", "č"),
        's' to listOf("š", "ß"),
        'y' to listOf("ý", "ÿ"),
        'z' to listOf("ž")
    )
    private val PUNCT = listOf(",", "?", "!", ":", ";", "…", "-")

    private fun chars(s: String) = s.map { Key(it.toString(), alts = ALTS[it].orEmpty()) }

    private fun bottom(left: Key) = listOf(
        left,
        Key(","),
        Key("😊", KeyType.EMOJI),
        Key(" ", KeyType.SPACE, 4f),
        Key(".", alts = PUNCT),
        Key("⏎", KeyType.ENTER, 1.5f)
    )

    fun letters(numberRow: Boolean): List<List<Key>> {
        val rows = mutableListOf<List<Key>>()
        if (numberRow) rows += chars("1234567890")
        rows += chars("qwertyuiop")
        rows += chars("asdfghjklñ")
        rows += listOf(Key("⇧", KeyType.SHIFT, 1.5f)) + chars("zxcvbnm") + Key("⌫", KeyType.DELETE, 1.5f)
        rows += bottom(Key("?123", KeyType.SYMBOLS, 1.5f))
        return rows
    }

    val symbols1: List<List<Key>> = listOf(
        chars("1234567890"),
        chars("@#€_&-+()/"),
        listOf(Key("=\\<", KeyType.MORE, 1.5f)) + chars("*\"':;!?") + Key("⌫", KeyType.DELETE, 1.5f),
        bottom(Key("ABC", KeyType.LETTERS, 1.5f))
    )

    val symbols2: List<List<Key>> = listOf(
        chars("~`|•√π÷×¶∆"),
        chars("£¢$¥^°={}\\"),
        listOf(Key("?123", KeyType.SYMBOLS_BACK, 1.5f)) + chars("%©®™<>…") + Key("⌫", KeyType.DELETE, 1.5f),
        bottom(Key("ABC", KeyType.LETTERS, 1.5f))
    )
}
