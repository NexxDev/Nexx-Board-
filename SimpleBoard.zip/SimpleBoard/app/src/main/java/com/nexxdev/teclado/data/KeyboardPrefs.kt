package com.nexxdev.teclado.data

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager

/** Lectura "en vivo" de los ajustes (las claves coinciden con res/xml/preferences.xml). */
class KeyboardPrefs(ctx: Context) {
    val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(ctx)

    var theme: String
        get() = sp.getString("theme", "system") ?: "system"
        set(v) = sp.edit().putString("theme", v).apply()

    var oneHanded: String
        get() = sp.getString("one_handed", "off") ?: "off"
        set(v) = sp.edit().putString("one_handed", v).apply()

    val heightPct: Int get() = sp.getInt("height", 100)
    val numberRow: Boolean get() = sp.getBoolean("number_row", true)
    val autoCap: Boolean get() = sp.getBoolean("auto_cap", true)
    val doubleSpace: Boolean get() = sp.getBoolean("double_space", true)
    val suggestions: Boolean get() = sp.getBoolean("suggestions", true)
    val learn: Boolean get() = sp.getBoolean("learn", true)
    val spaceCursor: Boolean get() = sp.getBoolean("space_cursor", true)
    val popups: Boolean get() = sp.getBoolean("popups", true)
    val autocorrect: String get() = sp.getString("autocorrect", "soft") ?: "soft"
    val keyPreview: Boolean get() = sp.getBoolean("key_preview", true)
    val haptic: Boolean get() = sp.getBoolean("haptic", true)
    val sound: Boolean get() = sp.getBoolean("sound", false)
}
