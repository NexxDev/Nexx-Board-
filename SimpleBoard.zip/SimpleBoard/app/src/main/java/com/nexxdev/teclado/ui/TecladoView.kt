package com.nexxdev.teclado.ui

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.graphics.Typeface
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.nexxdev.teclado.R
import com.nexxdev.teclado.data.ClipStore
import com.nexxdev.teclado.data.KeyboardPrefs
import kotlin.math.abs

/**
 * Toda la interfaz del teclado: barra de sugerencias/herramientas, teclas (QWERTY,
 * símbolos), emojis, panel de edición y portapapeles. No conoce el campo de texto:
 * avisa de lo que ocurre mediante [Listener].
 */
class TecladoView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    interface Listener {
        fun onText(text: String)
        fun onDelete()
        fun onEnter()
        fun onSuggestion(word: String)
        fun onKey(keyCode: Int, meta: Int)
        fun onMenuAction(id: Int)
        fun onCursorSteps(steps: Int)
        fun onOpenSettings()
        fun onPickKeyboard()
    }

    /** Una casilla de la barra de sugerencias (word = lo que se inserta, label = lo que se ve). */
    data class Sug(val word: String, val label: String = word, val primary: Boolean = false)

    var listener: Listener? = null

    private enum class Layer { LETTERS, SYMBOLS1, SYMBOLS2 }
    private enum class Panel { KEYS, EMOJI, EDIT, CLIP }

    private val prefs = KeyboardPrefs(context)
    private val ui = Handler(Looper.getMainLooper())
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private var theme = KeyboardTheme.resolve(context, "system")
    private var layer = Layer.LETTERS
    private var panel = Panel.KEYS
    private var shiftState = 0            // 0 = off, 1 = una vez, 2 = bloqueo
    private var lastShiftTap = 0L
    private var enterLabel = "⏎"
    private var selectMode = false
    private var emojiCat = 1

    private lateinit var suggestionStrip: View
    private lateinit var toolsStrip: View
    private lateinit var panelContainer: FrameLayout
    private lateinit var keysArea: LinearLayout
    private lateinit var emojiPanel: View
    private lateinit var emojiTabs: LinearLayout
    private lateinit var emojiGrid: GridLayout
    private lateinit var editPanel: LinearLayout
    private lateinit var clipPanel: View
    private lateinit var clipList: LinearLayout
    private lateinit var clipEmpty: TextView
    private lateinit var sugViews: List<TextView>
    private lateinit var topTexts: List<TextView>

    private var shiftView: TextView? = null
    private var selectView: TextView? = null
    private val letterViews = ArrayList<Pair<TextView, Key>>()

    // ------------------------------------------------------------------ init

    override fun onFinishInflate() {
        super.onFinishInflate()
        suggestionStrip = findViewById(R.id.suggestion_strip)
        toolsStrip = findViewById(R.id.tools_strip)
        panelContainer = findViewById(R.id.panel_container)
        keysArea = findViewById(R.id.keys_area)
        emojiPanel = findViewById(R.id.emoji_panel)
        emojiTabs = findViewById(R.id.emoji_tabs)
        emojiGrid = findViewById(R.id.emoji_grid)
        editPanel = findViewById(R.id.edit_panel)
        clipPanel = findViewById(R.id.clip_panel)
        clipList = findViewById(R.id.clip_list)
        clipEmpty = findViewById(R.id.clip_empty)

        sugViews = listOf(R.id.sug1, R.id.sug2, R.id.sug3).map { findViewById<TextView>(it) }
        topTexts = listOf(
            R.id.btn_tools, R.id.btn_close_tools, R.id.tool_edit, R.id.tool_clip,
            R.id.tool_emoji, R.id.tool_theme, R.id.tool_onehand, R.id.tool_settings, R.id.tool_switch
        ).map { findViewById<TextView>(it) }

        findViewById<View>(R.id.btn_tools).setOnClickListener { toolsOpen(true) }
        findViewById<View>(R.id.btn_close_tools).setOnClickListener { toolsOpen(false) }
        findViewById<View>(R.id.tool_edit).setOnClickListener { showPanel(Panel.EDIT) }
        findViewById<View>(R.id.tool_clip).setOnClickListener { showPanel(Panel.CLIP) }
        findViewById<View>(R.id.tool_emoji).setOnClickListener { showPanel(Panel.EMOJI) }
        findViewById<View>(R.id.tool_theme).setOnClickListener { cycleTheme() }
        findViewById<View>(R.id.tool_onehand).setOnClickListener { cycleOneHanded() }
        findViewById<View>(R.id.tool_settings).setOnClickListener { listener?.onOpenSettings() }
        findViewById<View>(R.id.tool_switch).setOnClickListener { listener?.onPickKeyboard() }

        sugViews.forEach { tv ->
            tv.setOnClickListener {
                val w = tv.tag as? String
                if (!w.isNullOrBlank()) listener?.onSuggestion(w)
            }
        }

        bindPress(findViewById(R.id.emoji_abc), false) { showPanel(Panel.KEYS) }
        bindPress(findViewById(R.id.emoji_del), true) { listener?.onDelete() }
        bindPress(findViewById(R.id.clip_back), false) { showPanel(Panel.KEYS) }
        bindPress(findViewById(R.id.clip_clear), false) { ClipStore.items.clear(); buildClips() }

        applySettings()
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------ API pública

    fun onStartInput(symbols: Boolean) {
        panel = Panel.KEYS
        layer = if (symbols) Layer.SYMBOLS1 else Layer.LETTERS
        selectMode = false
        shiftState = 0
        applySettings()
    }

    fun setSuggestions(list: List<Sug>) {
        sugViews.forEachIndexed { i, tv ->
            val s = list.getOrNull(i)
            tv.text = s?.label.orEmpty()
            tv.tag = s?.word.orEmpty()
            tv.setTypeface(null, if (s?.primary == true) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    fun setEnterLabel(label: String) {
        if (label != enterLabel) {
            enterLabel = label
            rebuildKeys()
        }
    }

    fun setShiftAuto(on: Boolean) {
        if (shiftState == 2) return
        val n = if (on) 1 else 0
        if (n != shiftState) {
            shiftState = n
            refreshShift()
        }
    }

    fun applySettings() {
        theme = KeyboardTheme.resolve(context, prefs.theme)
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val scale = prefs.heightPct / 100f * (if (landscape) 0.72f else 1f)
        val rows = if (prefs.numberRow) 5 else 4
        panelContainer.layoutParams = panelContainer.layoutParams.apply {
            height = (dp(52) * scale * rows).toInt() + dp(4)
        }
        applyOneHanded()
        styleStatic()
        rebuildKeys()
        showPanel(panel)
    }

    // ------------------------------------------------------------- estilo

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, radius: Int): Drawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun keyBg(color: Int, mix: Int = theme.text): Drawable {
        val pressed = ColorUtils.blendARGB(color, mix, 0.18f)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), round(pressed, dp(8)))
            addState(intArrayOf(), round(color, dp(8)))
        }
    }

    private fun styleStatic() {
        setBackgroundColor(theme.bg)
        topTexts.forEach { it.setTextColor(theme.text) }
        sugViews.forEach { it.setTextColor(theme.text) }
        listOf(R.id.emoji_abc, R.id.emoji_del, R.id.clip_back, R.id.clip_clear).forEach { id ->
            findViewById<TextView>(id).apply {
                setTextColor(theme.text)
                background = keyBg(theme.keySpecial)
            }
        }
        findViewById<TextView>(R.id.clip_title).setTextColor(theme.subText)
        clipEmpty.setTextColor(theme.subText)
    }

    private fun applyOneHanded() {
        val side = (resources.displayMetrics.widthPixels * 0.22f).toInt()
        when (prefs.oneHanded) {
            "left" -> setPadding(0, 0, side, dp(4))
            "right" -> setPadding(side, 0, 0, dp(4))
            else -> setPadding(0, 0, 0, dp(4))
        }
    }

    private fun toolsOpen(open: Boolean) {
        toolsStrip.visibility = if (open) View.VISIBLE else View.GONE
        suggestionStrip.visibility = if (open) View.GONE else View.VISIBLE
    }

    private fun cycleTheme() {
        prefs.theme = when (prefs.theme) {
            "light" -> "dark"
            "dark" -> "amoled"
            "amoled" -> "violet"
            "violet" -> if (Build.VERSION.SDK_INT >= 31) "dynamic" else "light"
            "dynamic" -> "light"
            else -> if (KeyboardTheme.isNight(context)) "light" else "dark"
        }
        applySettings()
    }

    private fun cycleOneHanded() {
        prefs.oneHanded = when (prefs.oneHanded) {
            "off" -> "right"
            "right" -> "left"
            else -> "off"
        }
        applyOneHanded()
    }

    // ------------------------------------------------------------- paneles

    private fun showPanel(p: Panel) {
        panel = p
        keysArea.visibility = if (p == Panel.KEYS) View.VISIBLE else View.GONE
        emojiPanel.visibility = if (p == Panel.EMOJI) View.VISIBLE else View.GONE
        editPanel.visibility = if (p == Panel.EDIT) View.VISIBLE else View.GONE
        clipPanel.visibility = if (p == Panel.CLIP) View.VISIBLE else View.GONE
        toolsOpen(false)
        when (p) {
            Panel.EMOJI -> buildEmoji()
            Panel.EDIT -> buildEdit()
            Panel.CLIP -> buildClips()
            else -> {}
        }
    }

    // ------------------------------------------------------------- teclas

    private fun rebuildKeys() {
        keysArea.removeAllViews()
        letterViews.clear()
        shiftView = null
        val rows = when (layer) {
            Layer.LETTERS -> KeyLayouts.letters(prefs.numberRow)
            Layer.SYMBOLS1 -> KeyLayouts.symbols1
            Layer.SYMBOLS2 -> KeyLayouts.symbols2
        }
        rows.forEach { keys ->
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            keys.forEach { row.addView(createKey(row, it)) }
            keysArea.addView(row)
        }
        refreshShift()
    }

    private fun display(key: Key): String = when {
        key.type == KeyType.SPACE -> " "
        key.type == KeyType.CHAR && layer == Layer.LETTERS && shiftState != 0 -> key.label.uppercase()
        else -> key.label
    }

    private fun createKey(row: ViewGroup, key: Key): View {
        val tv = LayoutInflater.from(context).inflate(R.layout.key_item, row, false) as TextView
        (tv.layoutParams as LinearLayout.LayoutParams).weight = key.weight

        val t = theme
        var bg = t.key
        var fg = t.text
        var size = 22f
        var label = display(key)
        when (key.type) {
            KeyType.SHIFT -> { bg = t.keySpecial; shiftView = tv }
            KeyType.DELETE -> { bg = t.keySpecial; size = 20f }
            KeyType.ENTER -> {
                bg = t.accent; fg = t.onAccent; label = enterLabel
                size = if (enterLabel.length > 1) 14f else 22f
            }
            KeyType.SYMBOLS, KeyType.LETTERS, KeyType.MORE, KeyType.SYMBOLS_BACK -> {
                bg = t.keySpecial; size = 15f
            }
            KeyType.EMOJI -> { bg = t.keySpecial; size = 20f }
            KeyType.SPACE -> { label = "Español"; fg = t.subText; size = 12f }
            KeyType.CHAR -> letterViews.add(tv to key)
        }
        tv.text = label
        tv.textSize = size
        tv.setTextColor(fg)
        tv.background = keyBg(bg)
        tv.setOnTouchListener(KeyTouch(key, tv))
        return tv
    }

    private fun refreshShift() {
        shiftView?.apply {
            text = if (shiftState == 2) "⇪" else "⇧"
            setTextColor(
                when (shiftState) {
                    2 -> theme.onAccent
                    1 -> theme.accent
                    else -> theme.text
                }
            )
            background = keyBg(if (shiftState == 2) theme.accent else theme.keySpecial)
        }
        if (layer == Layer.LETTERS) letterViews.forEach { (tv, k) -> tv.text = display(k) }
    }

    private fun toggleShift() {
        val now = SystemClock.uptimeMillis()
        shiftState = when {
            shiftState == 2 -> 0
            shiftState == 1 && now - lastShiftTap < 350 -> 2
            shiftState == 1 -> 0
            else -> 1
        }
        lastShiftTap = now
        refreshShift()
    }

    private fun setLayer(l: Layer) {
        layer = l
        rebuildKeys()
    }

    private fun commitChar(text: String) {
        listener?.onText(text)
        if (shiftState == 1) {
            shiftState = 0
            refreshShift()
        }
    }

    private fun perform(key: Key) {
        when (key.type) {
            KeyType.CHAR -> commitChar(display(key))
            KeyType.SPACE -> listener?.onText(" ")
            KeyType.SHIFT -> toggleShift()
            KeyType.ENTER -> listener?.onEnter()
            KeyType.SYMBOLS, KeyType.SYMBOLS_BACK -> setLayer(Layer.SYMBOLS1)
            KeyType.MORE -> setLayer(Layer.SYMBOLS2)
            KeyType.LETTERS -> setLayer(Layer.LETTERS)
            KeyType.EMOJI -> showPanel(Panel.EMOJI)
            KeyType.DELETE -> {}
        }
    }

    private fun feedback(v: View, type: KeyType = KeyType.CHAR) {
        if (prefs.haptic) {
            v.performHapticFeedback(
                HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        }
        if (prefs.sound) {
            val fx = when (type) {
                KeyType.SPACE -> AudioManager.FX_KEYPRESS_SPACEBAR
                KeyType.DELETE -> AudioManager.FX_KEYPRESS_DELETE
                KeyType.ENTER -> AudioManager.FX_KEYPRESS_RETURN
                else -> AudioManager.FX_KEYPRESS_STANDARD
            }
            audio.playSoundEffect(fx, 0.5f)
        }
    }

    /** Botón genérico: con [repeat] la acción se repite al mantener pulsado. */
    private fun bindPress(view: View, repeat: Boolean, action: () -> Unit) {
        val runner = object : Runnable {
            override fun run() {
                action()
                ui.postDelayed(this, 45)
            }
        }
        view.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    feedback(v)
                    if (repeat) {
                        action()
                        ui.postDelayed(runner, 400)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    ui.removeCallbacks(runner)
                    if (!repeat) action()
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    ui.removeCallbacks(runner)
                }
            }
            true
        }
    }

    // ---------------------------------------------------- toque de una tecla

    private inner class KeyTouch(private val key: Key, private val v: TextView) : View.OnTouchListener {
        private var popup: AltPopup? = null
        private var preview: PopupWindow? = null
        private var moved = false
        private var downX = 0f
        private var lastX = 0f

        private val longRunnable = Runnable {
            if (key.alts.isNotEmpty() && prefs.popups) {
                val opts = listOf(display(key)) + key.alts.map {
                    if (layer == Layer.LETTERS && shiftState != 0) it.uppercase() else it
                }
                preview?.dismiss()
                preview = null
                popup = AltPopup(v, opts)
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            }
        }
        private val repeatRunnable = object : Runnable {
            override fun run() {
                listener?.onDelete()
                ui.postDelayed(this, 45)
            }
        }

        override fun onTouch(view: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    moved = false
                    downX = e.rawX
                    lastX = e.rawX
                    feedback(v, key.type)
                    if (prefs.keyPreview && key.type == KeyType.CHAR) preview = showPreview(v, display(key))
                    if (key.type == KeyType.DELETE) {
                        listener?.onDelete()
                        ui.postDelayed(repeatRunnable, 400)
                    } else if (key.alts.isNotEmpty()) {
                        ui.postDelayed(longRunnable, 350)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    popup?.update(e.rawX)
                    if (key.type == KeyType.SPACE && prefs.spaceCursor &&
                        (moved || abs(e.rawX - downX) > dp(14))
                    ) {
                        val step = dp(16)
                        val n = ((e.rawX - lastX) / step).toInt()
                        if (n != 0) {
                            moved = true
                            lastX += n * step
                            listener?.onCursorSteps(n)
                        }
                    }
                }
                MotionEvent.ACTION_UP -> end(!isOutside(e))
                MotionEvent.ACTION_CANCEL -> end(false)
            }
            return true
        }

        private fun isOutside(e: MotionEvent): Boolean {
            if (key.type == KeyType.SPACE || popup != null) return false
            val slop = dp(24)
            return e.x < -slop || e.x > v.width + slop || e.y < -slop || e.y > v.height + slop
        }

        private fun end(commit: Boolean) {
            ui.removeCallbacks(longRunnable)
            ui.removeCallbacks(repeatRunnable)
            v.isPressed = false
            preview?.dismiss()
            preview = null
            val p = popup
            popup = null
            if (commit) {
                when {
                    p != null -> commitChar(p.chosen())
                    key.type == KeyType.DELETE -> {}
                    moved -> {}
                    else -> perform(key)
                }
            }
            p?.dismiss()
        }
    }

    /** Globo con la letra pulsada (como Gboard). */
    private fun showPreview(anchor: View, label: String): PopupWindow? = try {
        val w = (anchor.width * 1.4f).toInt()
        val h = (anchor.height * 1.2f).toInt()
        val tv = TextView(context).apply {
            text = label
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(theme.text)
            background = round(theme.popup, dp(10))
        }
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        val screenW = resources.displayMetrics.widthPixels
        val x = (loc[0] + anchor.width / 2 - w / 2).coerceIn(0, maxOf(0, screenW - w))
        val y = loc[1] - h - dp(2)
        PopupWindow(tv, w, h, false).apply {
            isTouchable = false
            isClippingEnabled = false
            elevation = dp(6).toFloat()
            showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
        }
    } catch (e: Exception) {
        null
    }

    /** Globo con caracteres alternativos; se elige deslizando y soltando. */
    private inner class AltPopup(anchor: View, opts: List<String>) {
        private val options: List<String>
        private val views = ArrayList<TextView>()
        private val window: PopupWindow
        private val startX: Int
        private val itemW: Int
        private var sel: Int

        init {
            val pad = dp(4)
            val itemH = dp(50)
            val screenW = resources.displayMetrics.widthPixels
            itemW = minOf(maxOf(anchor.width, dp(38)), (screenW - 2 * pad) / opts.size)
            val total = opts.size * itemW + pad * 2

            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            val rightward = loc[0] - pad + total <= screenW
            options = if (rightward) opts else opts.reversed()
            sel = if (rightward) 0 else opts.size - 1

            val content = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(pad, pad, pad, pad)
                background = round(theme.popup, dp(10))
            }
            options.forEach { o ->
                val tv = TextView(context).apply {
                    text = o
                    textSize = 22f
                    gravity = Gravity.CENTER
                    setTextColor(theme.text)
                    layoutParams = LinearLayout.LayoutParams(itemW, itemH)
                }
                views.add(tv)
                content.addView(tv)
            }

            var x = if (rightward) loc[0] - pad else loc[0] + anchor.width - total + pad
            x = x.coerceIn(0, maxOf(0, screenW - total))
            startX = x + pad
            val y = loc[1] - itemH - pad * 2 - dp(6)

            window = PopupWindow(content, total, itemH + pad * 2, false).apply {
                isTouchable = false
                isClippingEnabled = false
                elevation = dp(6).toFloat()
            }
            window.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
            highlight()
        }

        fun update(rawX: Float) {
            val i = ((rawX - startX) / itemW).toInt().coerceIn(0, options.size - 1)
            if (i != sel) {
                sel = i
                highlight()
            }
        }

        private fun highlight() {
            views.forEachIndexed { i, tv ->
                tv.background = if (i == sel) round(theme.accent, dp(8)) else null
                tv.setTextColor(if (i == sel) theme.onAccent else theme.text)
            }
        }

        fun chosen(): String = options[sel]
        fun dismiss() = window.dismiss()
    }

    // ------------------------------------------------------------- emojis

    private fun recents(): List<String> =
        (prefs.sp.getString("emoji_recents", "") ?: "").split(" ").filter { it.isNotBlank() }

    private fun addRecent(e: String) {
        val l = listOf(e) + recents().filter { it != e }
        prefs.sp.edit().putString("emoji_recents", l.take(32).joinToString(" ")).apply()
    }

    private fun buildEmoji() {
        val cats = listOf("🕘" to recents()) + EmojiData.categories
        emojiCat = emojiCat.coerceIn(0, cats.size - 1)

        emojiTabs.removeAllViews()
        cats.forEachIndexed { i, (icon, _) ->
            emojiTabs.addView(TextView(context).apply {
                text = icon
                textSize = 20f
                gravity = Gravity.CENTER
                setPadding(dp(14), 0, dp(14), 0)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
                alpha = if (i == emojiCat) 1f else 0.4f
                setOnClickListener { emojiCat = i; buildEmoji() }
            })
        }

        emojiGrid.removeAllViews()
        cats[emojiCat].second.forEach { e ->
            emojiGrid.addView(TextView(context).apply {
                text = e
                textSize = 26f
                gravity = Gravity.CENTER
                layoutParams = GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED),
                    GridLayout.spec(GridLayout.UNDEFINED, 1f)
                ).apply {
                    width = 0
                    height = dp(46)
                }
                setOnClickListener {
                    listener?.onText(e)
                    addRecent(e)
                }
            })
        }
    }

    // ------------------------------------------------------------- edición

    private val editLayout = listOf(
        listOf("Todo" to "all", "Cortar" to "cut", "Copiar" to "copy", "Pegar" to "paste"),
        listOf("↶" to "undo", "↷" to "redo", "Inicio" to "home", "Fin" to "end"),
        listOf("«Pal" to "wleft", "←" to "left", "→" to "right", "Pal»" to "wright"),
        listOf("↑" to "up", "↓" to "down", "Selec." to "select", "ABC" to "back")
    )

    private fun buildEdit() {
        editPanel.removeAllViews()
        selectView = null
        val repeating = setOf("left", "right", "up", "down", "wleft", "wright")
        editLayout.forEach { r ->
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            r.forEach { (label, code) ->
                val tv = LayoutInflater.from(context).inflate(R.layout.key_item, row, false) as TextView
                tv.text = label
                tv.textSize = if (label.length > 2) 15f else 22f
                tv.setTextColor(theme.text)
                tv.background = keyBg(theme.keySpecial)
                if (code == "select") selectView = tv
                bindPress(tv, code in repeating) { editAction(code) }
                row.addView(tv)
            }
            editPanel.addView(row)
        }
        paintSelect()
    }

    private fun paintSelect() {
        selectView?.apply {
            background = keyBg(if (selectMode) theme.accent else theme.keySpecial)
            setTextColor(if (selectMode) theme.onAccent else theme.text)
        }
    }

    private fun editAction(code: String) {
        val l = listener ?: return
        val shift = if (selectMode) KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON else 0
        val ctrl = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        when (code) {
            "all" -> l.onMenuAction(android.R.id.selectAll)
            "cut" -> l.onMenuAction(android.R.id.cut)
            "copy" -> l.onMenuAction(android.R.id.copy)
            "paste" -> l.onMenuAction(android.R.id.paste)
            "undo" -> l.onKey(KeyEvent.KEYCODE_Z, ctrl)
            "redo" -> l.onKey(KeyEvent.KEYCODE_Z, ctrl or KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON)
            "home" -> l.onKey(KeyEvent.KEYCODE_MOVE_HOME, shift)
            "end" -> l.onKey(KeyEvent.KEYCODE_MOVE_END, shift)
            "left" -> l.onKey(KeyEvent.KEYCODE_DPAD_LEFT, shift)
            "right" -> l.onKey(KeyEvent.KEYCODE_DPAD_RIGHT, shift)
            "up" -> l.onKey(KeyEvent.KEYCODE_DPAD_UP, shift)
            "down" -> l.onKey(KeyEvent.KEYCODE_DPAD_DOWN, shift)
            "wleft" -> l.onKey(KeyEvent.KEYCODE_DPAD_LEFT, shift or ctrl)
            "wright" -> l.onKey(KeyEvent.KEYCODE_DPAD_RIGHT, shift or ctrl)
            "select" -> { selectMode = !selectMode; paintSelect() }
            "back" -> showPanel(Panel.KEYS)
        }
    }

    // ------------------------------------------------------------- portapapeles

    private fun buildClips() {
        clipList.removeAllViews()
        val items = ClipStore.items
        clipEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        items.forEach { clip ->
            clipList.addView(TextView(context).apply {
                text = clip
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                textSize = 15f
                setTextColor(theme.text)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = keyBg(theme.key)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp(8), dp(3), dp(8), dp(3)) }
                setOnClickListener {
                    listener?.onText(clip)
                    showPanel(Panel.KEYS)
                }
            })
        }
    }
}
