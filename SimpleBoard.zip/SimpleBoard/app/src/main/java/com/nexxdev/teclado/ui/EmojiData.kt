package com.nexxdev.teclado.ui

/** Emojis estáticos, sin red. Icono de pestaña -> lista. */
object EmojiData {
    private fun l(s: String) = s.split(" ").filter { it.isNotBlank() }

    val categories: List<Pair<String, List<String>>> = listOf(
        "😀" to l("😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😙 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 😐 😑 😶 😏 😒 🙄 😬 😮 😯 😲 😳 🥺 😢 😭 😤 😠 😡 🤯 😱 😨 😰 😥 😓 🥱 😴 🤤 😷 🤒 🤕 🤢 🤮 🥵 🥶 😎 🤓 🥳"),
        "👍" to l("👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤝 🙏 👏 🙌 👐 🤲 💪 ✍️ 🤳 🙋 🤷 🤦 🙆 🙅 💁 🙇"),
        "❤️" to l("❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 ✨ ⭐ 🌟 💫 🔥 💥 💯 ✅ ❌ ❓ ❗ ⚠️ ➕ ➖ ✔️ ➡️ ⬅️ ⬆️ ⬇️ 🔔 🔒 🔑"),
        "🐶" to l("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🐺 🐴 🦄 🐝 🦋 🐌 🐞 🐢 🐍 🐙 🐬 🐳 🌸 🌹 🌻 🌲 🌴 🌞 🌙 🌈 ☁️ ⛄"),
        "🍔" to l("🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🥕 🌽 🥔 🍞 🧀 🥚 🍳 🥓 🍔 🍟 🍕 🌭 🌮 🌯 🍝 🍜 🍣 🍦 🍩 🍪 🎂 🍫 🍿 ☕ 🍺 🍷 🥤"),
        "⚽" to l("⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🥊 🎮 🎲 🎯 🎵 🎶 🎤 🎧 🎸 🎹 🎬 🎨 🚗 🚕 🚌 🚲 🏍️ ✈️ 🚀 🚢 🏠 🏖️ ⛰️ 🎉 🎁 🎈"),
        "💡" to l("📱 💻 ⌨️ 🖥️ 📷 📺 🔋 💡 🔦 📚 📖 ✏️ 📝 📎 📌 ✂️ 🔧 🔨 ⚙️ 💰 💳 📦 📧 📅 ⏰ ⌚ 🔍 🎒 👓 👕 👟")
    )
}
