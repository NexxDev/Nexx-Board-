package com.nexxdev.teclado.ui

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build

data class KeyboardTheme(
    val bg: Int,
    val key: Int,
    val keySpecial: Int,
    val accent: Int,
    val onAccent: Int,
    val text: Int,
    val subText: Int,
    val popup: Int
) {
    companion object {
        private fun c(s: String) = Color.parseColor(s)

        private val LIGHT = KeyboardTheme(
            c("#ECEFF1"), c("#FFFFFF"), c("#CFD8DC"), c("#1A73E8"),
            c("#FFFFFF"), c("#202124"), c("#5F6368"), c("#FFFFFF")
        )
        private val DARK = KeyboardTheme(
            c("#202124"), c("#3C4043"), c("#2B2D30"), c("#8AB4F8"),
            c("#202124"), c("#E8EAED"), c("#9AA0A6"), c("#3C4043")
        )
        private val AMOLED = KeyboardTheme(
            c("#000000"), c("#1C1C1E"), c("#0E0E10"), c("#4DD0E1"),
            c("#000000"), c("#F2F2F2"), c("#8E8E93"), c("#2C2C2E")
        )
        private val VIOLET = KeyboardTheme(
            c("#1B1530"), c("#2E2550"), c("#241C40"), c("#B388FF"),
            c("#1B1530"), c("#EDE7F6"), c("#9E94B8"), c("#2E2550")
        )

        fun resolve(ctx: Context, name: String): KeyboardTheme = when (name) {
            "light" -> LIGHT
            "dark" -> DARK
            "amoled" -> AMOLED
            "violet" -> VIOLET
            "dynamic" -> if (Build.VERSION.SDK_INT >= 31) dynamic(ctx) else if (isNight(ctx)) DARK else LIGHT
            else -> if (isNight(ctx)) DARK else LIGHT
        }

        /** Material You: colores del sistema (Android 12+), como Gboard. */
        private fun dynamic(ctx: Context): KeyboardTheme {
            fun col(id: Int) = ctx.getColor(id)
            return if (isNight(ctx)) KeyboardTheme(
                col(android.R.color.system_neutral1_900), col(android.R.color.system_neutral2_700),
                col(android.R.color.system_neutral1_800), col(android.R.color.system_accent1_200),
                col(android.R.color.system_accent1_800), col(android.R.color.system_neutral1_100),
                col(android.R.color.system_neutral2_300), col(android.R.color.system_neutral2_700)
            ) else KeyboardTheme(
                col(android.R.color.system_neutral2_100), col(android.R.color.system_neutral1_0),
                col(android.R.color.system_neutral2_200), col(android.R.color.system_accent1_600),
                col(android.R.color.system_accent1_0), col(android.R.color.system_neutral1_900),
                col(android.R.color.system_neutral2_600), col(android.R.color.system_neutral1_0)
            )
        }

        fun isNight(ctx: Context): Boolean =
            (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
    }
}
