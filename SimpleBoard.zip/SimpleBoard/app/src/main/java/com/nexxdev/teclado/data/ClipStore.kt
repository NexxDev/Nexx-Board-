package com.nexxdev.teclado.data

/** Historial del portapapeles: solo en memoria (se pierde al cerrarse el servicio). */
object ClipStore {
    val items = ArrayDeque<String>()

    fun add(text: String) {
        items.remove(text)
        items.addFirst(text)
        while (items.size > 25) items.removeLast()
    }
}
