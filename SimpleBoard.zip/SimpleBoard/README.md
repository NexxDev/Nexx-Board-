# Simple Board

Teclado Android (InputMethodService, Kotlin) **100% offline**: sin permiso de internet, sin servidores, sin telemetría.

## Funciones
- QWERTY en español (con ñ), fila de números, símbolos, emojis (con recientes), vista previa de tecla
- Pulsación larga para caracteres alternativos (á, é, ç…): desliza y suelta
- Mayúscula (una vez / bloqueo con doble toque) y mayúscula automática
- Deslizar sobre la barra espaciadora para mover el cursor
- **Autocorrector local** (apagado / suave / normal): acentos, letras cambiadas de sitio y letras de más o menos
  - Borrar justo después de una corrección la deshace y enseña al teclado que esa palabra es válida
  - Aprende tus palabras y las parejas de palabras para predecir la siguiente; todo en `files/` del teléfono
- Barra de sugerencias estilo Gboard (palabra escrita entre comillas, mejor opción en negrita en el centro)
- Panel de edición, historial del portapapeles, punto con doble espacio
- Temas: automático, claro, oscuro, AMOLED, violeta y Material You (Android 12+); altura de teclas; modo una mano

## Compilar
- GitHub Actions: sube el repo (o solo `SimpleBoard.zip` + el workflow) y descarga el artefacto `Simple-Board-APK` (`app-debug.apk`)
- Android Studio: abrir la carpeta y *Run*
