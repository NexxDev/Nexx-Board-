# Teclado Nexx

Teclado Android (InputMethodService, Kotlin) **100% offline**: sin permiso de internet, sin servidores, sin telemetría.

## Funciones
- QWERTY en español (con ñ), fila de números opcional, símbolos (2 páginas) y emojis por categorías + recientes
- Pulsación larga para caracteres alternativos (á, é, ç…): desliza y suelta
- Mayúscula (una vez / bloqueo con doble toque) y mayúscula automática
- Deslizar sobre la barra espaciadora para mover el cursor
- Sugerencias con diccionario local + aprendizaje de tus palabras (archivo local)
- Punto con doble espacio; tecla Enter según el campo (Ir, Buscar, Enviar…)
- Panel de edición: seleccionar todo, cortar, copiar, pegar, deshacer/rehacer, flechas, inicio/fin, saltar por palabra, modo selección
- Historial del portapapeles (solo en memoria; ignora campos de contraseña)
- Temas: automático, claro, oscuro, AMOLED, violeta · altura de teclas · modo una mano
- Vibración y sonido opcionales

## Compilar
- Android Studio: abrir la carpeta y *Run* (o `gradle assembleDebug`)
- GitHub: sube el repo y el workflow `.github/workflows/build.yml` genera el APK (pestaña *Actions* → artefacto `teclado-debug-apk`)

## Ideas pendientes
Escritura por deslizamiento (glide), más idiomas (otro `words_xx.txt`), autocorrección, voz offline.
