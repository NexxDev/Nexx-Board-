package com.nexxdev.teclado

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import java.io.File

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settings_container, SettingsFragment())
                .commit()
        }
    }

    class SettingsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            findPreference<Preference>("clear_dict")?.setOnPreferenceClickListener {
                File(requireContext().filesDir, "user_words.txt").delete()
                Toast.makeText(requireContext(), "Diccionario personal borrado", Toast.LENGTH_SHORT).show()
                true
            }
            findPreference<Preference>("clear_emoji")?.setOnPreferenceClickListener {
                preferenceManager.sharedPreferences?.edit()?.remove("emoji_recents")?.apply()
                Toast.makeText(requireContext(), "Emojis recientes borrados", Toast.LENGTH_SHORT).show()
                true
            }
        }
    }
}
