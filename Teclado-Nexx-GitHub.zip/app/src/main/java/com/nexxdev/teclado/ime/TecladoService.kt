package com.nexxdev.teclado.ime

import android.content.ClipboardManager
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import com.nexxdev.teclado.R
import com.nexxdev.teclado.SettingsActivity
import com.nexxdev.teclado.data.ClipStore
import com.nexxdev.teclado.data.KeyboardPrefs
import com.nexxdev.teclado.data.WordEngine
import com.nexxdev.teclado.ui.TecladoView

/**
 * Servicio del teclado. Toda la UI vive en TecladoView; aquí está la lógica
 * que habla con el campo de texto (InputConnection).
 */
class TecladoService : InputMethodService(), TecladoView.Listener {

    private lateinit var prefs: KeyboardPrefs
    private lateinit var words: WordEngine
    private var tecladoView: TecladoView? = null
    private var clipboard: ClipboardManager? = null

    private var isPassword = false
    private var suggestionsAllowed = true
    private var autoCapAllowed = true
    private var lastSpaceTime = 0L

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    override fun onCreate() {
        super.onCreate()
        prefs = KeyboardPrefs(this)
        words = WordEngine(this)
        clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        clipboard?.removePrimaryClipChangedListener(clipListener)
        words.save()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val v = layoutInflater.inflate(R.layout.keyboard_view, null) as TecladoView
        v.listener = this
        tecladoView = v
        return v
    }

    // Evita el modo pantalla completa en horizontal
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION

        val textPass = cls == InputType.TYPE_CLASS_TEXT && (
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
        val numPass = cls == InputType.TYPE_CLASS_NUMBER &&
            variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
        isPassword = textPass || numPass

        val noSuggest = cls != InputType.TYPE_CLASS_TEXT ||
            (info.inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0 ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI
        suggestionsAllowed = !isPassword && !noSuggest
        autoCapAllowed = cls == InputType.TYPE_CLASS_TEXT && !isPassword

        words.syncIfCleared()

        val symbols = cls == InputType.TYPE_CLASS_NUMBER ||
            cls == InputType.TYPE_CLASS_PHONE ||
            cls == InputType.TYPE_CLASS_DATETIME
        tecladoView?.onStartInput(symbols)
        tecladoView?.setEnterLabel(enterLabel(info))
        refreshState()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        words.save()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(
            oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd
        )
        refreshState()
    }

    // ---------- Estado (mayúscula automática + sugerencias) ----------

    private fun refreshState() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        if (prefs.autoCap && autoCapAllowed && ei != null && ei.inputType != 0) {
            tecladoView?.setShiftAuto(ic.getCursorCapsMode(ei.inputType) != 0)
        }
        updateSuggestions()
    }

    private fun currentWord(before: CharSequence?): String =
        before?.toString().orEmpty().takeLastWhile { it.isLetter() }

    private fun updateSuggestions() {
        if (!prefs.suggestions || !suggestionsAllowed) {
            tecladoView?.setSuggestions(emptyList())
            return
        }
        val before = currentInputConnection?.getTextBeforeCursor(32, 0)
        tecladoView?.setSuggestions(words.suggest(currentWord(before)))
    }

    private fun learnCurrentWord() {
        if (!prefs.learn || isPassword || !suggestionsAllowed) return
        val before = currentInputConnection?.getTextBeforeCursor(32, 0)
        val w = currentWord(before)
        if (w.length >= 3) words.learn(w)
    }

    private fun enterLabel(info: EditorInfo): String {
        if ((info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) return "⏎"
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "⏎"
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "Ir"
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_SEND -> "Enviar"
            EditorInfo.IME_ACTION_NEXT -> "Sig."
            EditorInfo.IME_ACTION_DONE -> "✓"
            else -> "⏎"
        }
    }

    // ---------- TecladoView.Listener ----------

    override fun onText(text: String) {
        val ic = currentInputConnection ?: return
        if (text == " ") {
            val now = SystemClock.uptimeMillis()
            if (prefs.doubleSpace && now - lastSpaceTime < 450) {
                val before = ic.getTextBeforeCursor(2, 0)
                if (before != null && before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                    ic.deleteSurroundingText(1, 0)
                    ic.commitText(". ", 1)
                    lastSpaceTime = 0
                    return
                }
            }
            lastSpaceTime = now
        } else {
            lastSpaceTime = 0
        }
        if (text.length == 1 && !text[0].isLetter()) learnCurrentWord()
        ic.commitText(text, 1)
    }

    override fun onDelete() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        learnCurrentWord()
        val multi = ei != null && (ei.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        val noAction = ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        val action = if (ei != null) ei.imeOptions and EditorInfo.IME_MASK_ACTION else EditorInfo.IME_ACTION_NONE
        if (multi || noAction || action == EditorInfo.IME_ACTION_NONE ||
            action == EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            ic.performEditorAction(action)
        }
    }

    override fun onSuggestion(word: String) {
        val ic = currentInputConnection ?: return
        val current = currentWord(ic.getTextBeforeCursor(32, 0))
        ic.beginBatchEdit()
        if (current.isNotEmpty()) ic.deleteSurroundingText(current.length, 0)
        ic.commitText("$word ", 1)
        ic.endBatchEdit()
        if (prefs.learn && !isPassword) words.learn(word)
    }

    override fun onKey(keyCode: Int, meta: Int) {
        val ic = currentInputConnection ?: return
        val t = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, keyCode, 0, meta))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, keyCode, 0, meta))
    }

    override fun onMenuAction(id: Int) {
        currentInputConnection?.performContextMenuAction(id)
    }

    override fun onCursorSteps(steps: Int) {
        val code = if (steps < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        repeat(kotlin.math.abs(steps)) { onKey(code, 0) }
    }

    override fun onOpenSettings() {
        startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onPickKeyboard() {
        getSystemService(InputMethodManager::class.java)?.showInputMethodPicker()
    }

    // ---------- Portapapeles ----------

    private fun captureClip() {
        if (isPassword) return
        val clip = clipboard?.primaryClip ?: return
        if (clip.itemCount == 0) return
        val extras = clip.description.extras
        if (extras != null && extras.getBoolean("android.content.extra.IS_SENSITIVE", false)) return
        val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim()
        if (!text.isNullOrEmpty()) ClipStore.add(text)
    }
}
