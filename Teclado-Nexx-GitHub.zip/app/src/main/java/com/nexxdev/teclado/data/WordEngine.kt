package com.nexxdev.teclado.data

import android.content.Context
import java.io.File

/**
 * Motor de sugerencias 100% local:
 *  - assets/words_es.txt (diccionario base, una palabra por línea, por frecuencia)
 *  - palabras aprendidas del usuario (files/user_words.txt)
 */
class WordEngine(private val ctx: Context) {
    private val base = ArrayList<String>()
    private val user = HashMap<String, Int>()
    private var dirty = false
    private val file: File get() = File(ctx.filesDir, "user_words.txt")

    init {
        try {
            ctx.assets.open("words_es.txt").bufferedReader().useLines { seq ->
                seq.map { it.trim() }.filter { it.isNotEmpty() }.forEach { base.add(it) }
            }
        } catch (_: Exception) {
        }
        loadUser()
    }

    private fun loadUser() {
        user.clear()
        try {
            if (file.exists()) file.forEachLine { line ->
                val p = line.split('\t')
                if (p.size == 2) user[p[0]] = p[1].toIntOrNull() ?: 1
            }
        } catch (_: Exception) {
        }
    }

    /** Si el usuario borró el diccionario desde Ajustes, vacía también la memoria. */
    fun syncIfCleared() {
        if (!file.exists() && user.isNotEmpty() && !dirty) user.clear()
    }

    fun suggest(prefix: String, max: Int = 3): List<String> {
        val p = prefix.lowercase()
        if (p.isEmpty()) return emptyList()
        val out = LinkedHashSet<String>()
        user.entries
            .filter { it.key.startsWith(p) && it.key != p }
            .sortedByDescending { it.value }
            .take(max)
            .forEach { out.add(it.key) }
        for (w in base) {
            if (out.size >= max) break
            if (w.startsWith(p) && w != p) out.add(w)
        }
        return out.map { matchCase(prefix, it) }
    }

    private fun matchCase(prefix: String, word: String): String = when {
        prefix.length > 1 && prefix.all { it.isUpperCase() } -> word.uppercase()
        prefix.first().isUpperCase() -> word.replaceFirstChar { it.uppercase() }
        else -> word
    }

    fun learn(word: String) {
        val w = word.lowercase()
        if (w.length < 2 || !w.all { it.isLetter() }) return
        user[w] = (user[w] ?: 0) + 1
        dirty = true
    }

    fun save() {
        if (!dirty) return
        try {
            file.writeText(user.entries.joinToString("\n") { "${it.key}\t${it.value}" })
            dirty = false
        } catch (_: Exception) {
        }
    }
}
